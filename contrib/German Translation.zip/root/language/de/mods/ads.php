<?php
/**
*
* @package phpBB3 Advertisement Management
* @version $Id: ads.php 58 2008-09-15 19:00:41Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//
// Translation Copyright by juport.com!
// Deutscher Support und Deutsche Tutorials unter www.juport.com!
// Übersetzung Copyright bei juport.com!

$lang = array_merge($lang, array(
	'ADVERTISEMENT_MANAGEMENT_CREDITS'		=> 'Advertisements by <a href="http://www.lithiumstudios.org/">Advertisement Management</a><br />Deutsche Übersetzung durch <a href="http://juport.com/">JUPORT</a>.',

	// Default Positions
	'ABOVE_FOOTER'			=> 'Über Footer',
	'ABOVE_HEADER'			=> 'Über Header',
	'ABOVE_POSTS'			=> 'Über Posts',
	'AFTER_EVERY_POST'		=> 'Nach jedem Beitrag',
	'AFTER_FIRST_POST'		=> 'Nach dem ersten Beitrag',
	'BELOW_FOOTER'			=> 'Unter Footer',
	'BELOW_HEADER'			=> 'Unter Header',
	'BELOW_POSTS'			=> 'Unter Post',

	// ACP
	'0_OR_NA'									=> '0 oder N/A',

	'ACP_ADVERTISEMENT_MANAGEMENT_EXPLAIN'		=> 'Hier kannst du das Werbesystem verwalten. Du kannst auf diesen Seiten Bannerwerbung hinzufügen und bearbeiten, sowohl auch die Position verschieben etc.! Sei sicher das du alle Styleänderungen erfolgreich geändert hast.',
	'ACP_ADVERTISEMENT_MANAGEMENT_SETTINGS'		=> 'Advertisement Management Einstellungen',
	'ADS_ACCURATE_VIEWS'						=> 'Views-Counter',
	'ADS_ACCURATE_VIEWS_EXPLAIN'				=> 'Macht die Zählung der Views (Wenn bei der Werbung aktiv ist, wird es trotzdem nicht gezählt). Auswahl erhöht die Serverlast. ',
	'ADS_COUNT_CLICKS'							=> 'Klick-Counter',
	'ADS_COUNT_CLICKS_EXPLAIN'					=> 'Wenn du auf "nein" stellst, werden die Klicks nicht gezählt. (weniger Serverlast)',
	'ADS_COUNT_VIEWS'							=> 'Hinzugefügte Werbung-Counter',
	'ADS_COUNT_VIEWS_EXPLAIN'					=> 'Wenn du auf "nein" stellst, wird die Werbung nicht gezählt.',
	'AD_CREATED'								=> 'Erstellt am',
	'ADS_ENABLE'								=> 'Aktiviere Werbung',
	'ADS_RULES_FORUMS'							=> 'Benutze Forenregeln für Werbung',
	'ADS_RULES_FORUMS_EXPLAIN'					=> 'Wähle "nein" das die Werbung nicht angezeigt wird.',
	'ADS_RULES_GROUPS'							=> 'Benutze Gruppenregeln für Werbung',
	'ADS_RULES_GROUPS_EXPLAIN'					=> 'Wähle "nein" das die Werbung nicht angezeigt wird.',
	'ADS_VERSION'								=> 'Deine Version',
	'ADVERTISEMENT'								=> 'Werbung',
	'ADVERTISEMENT_MANAGEMENT_UPDATE_SUCCESS'	=> 'Die Advertisement Management wurden erfolgreich geändert!',
	'AD_ADD_SUCCESS'							=> 'Werbung erfolgreich hinzugefügt!',
	'AD_CLICK_LIMIT'							=> 'Klicks Limit',
	'AD_CLICK_LIMIT_EXPLAIN'					=> '0 to disable, otherwise the ad will become disabled after this number of clicks.',
	'AD_CLICKS'									=> 'Clicks',
	'AD_CLICKS_EXPLAIN'							=> 'Die Anzahl der Klicks für die Werbung (setup).',
	'AD_CODE'									=> 'HTML-Code',
	'AD_CODE_EXPLAIN'							=> 'Bitte gebe hier ein HTML-Code ein. Um die "Klicks" Funktion zu nutzen, füge "{COUNT_CLICK}" in eine Stelle, die angeklickt wird (den Tag z.B.).',
	'AD_EDIT_SUCCESS'							=> 'Werbung / Position erfolgreich geändert!',
	'AD_ENABLED'								=> 'Aktiv',
	'AD_ENABLED_EXPLAIN'						=> 'Auswählen, wenn es angezeigt werden soll.',
	'AD_FORUMS'									=> 'Forum Liste',
	'AD_FORUMS_EXPLAIN'							=> 'Wähle die Foren aus, in der die Werbung angezeigt werden soll. Mit STRG kannst du die Makierung rückgängig machen.',
	'AD_GROUPS'									=> 'Gruppen',
	'AD_GROUPS_EXPLAIN'							=> 'Wähle Gruppen aus für die, die Werbung <strong>NICHT</strong> zusehen sein soll. Makierung mit STRG aufheben :)',
	'AD_LIST_NOTICE'							=> 'Nutze {COUNT_CLICK} in deinem HTML-Code der Werbung. Nur so kann die Funktion "Clicks" ausgeführt werden <br /> <br /><br /><br /><br /><center><font size="1">Deutsche Übersetzung durch <a href="http://juport.com/">JUPORT</a>. <br />Deutscher Support und Download bei <a href="http://juport.com/">JUPORT</a>.</center></font>',
	'AD_MAX_VIEWS'								=> 'Max Views',
	'AD_MAX_VIEWS_EXPLAIN'						=> '<strong>0 ist kein Limit</strong>.',
	'AD_NAME'									=> 'Name',
	'AD_NAME_EXPLAIN'							=> 'Name der Werbung/Position',
	'AD_NOT_EXIST'								=> 'Die ausgewählte Werbung/Position existiert nicht.',
	'AD_NOTE'									=> 'Notizen',
	'AD_NOTE_EXPLAIN'							=> 'Wird nur im ACP angezeigt. Dient nur zur Orientierung.',
	'AD_POSITIONS'								=> 'Position',
	'AD_POSITIONS_EXPLAIN'						=> 'Wähle die Position aus.',
	'AD_PRIORITY'								=> 'Priorität',
	'AD_PRIORITY_EXPLAIN'						=> 'Desto höher die Nummer, je öfter wird die Werbung angezeigt.',
	'AD_TIME_END'								=> 'Laufzeit',
	'AD_TIME_END_BEFORE_NOW'					=> 'Die angegebene Zeit liegt in der Vergangenheit.',
	'AD_TIME_END_EXPLAIN'						=> 'Die Zeit muss nach <a href="http://us2.php.net/manual/en/function.strtotime.php">strtotime</a> Format sein.</strong>',
	'AD_VIEW_LIMIT'								=> 'Views Limit',
	'AD_VIEW_LIMIT_EXPLAIN'						=> '0 to disable, otherwise the ad will become disabled after this number of views.',
	'AD_VIEWS'									=> 'Views',
	'AD_VIEWS_EXPLAIN'							=> 'Die Anzahl, wie oft die Werbung angezeigt werden soll.',
	'ALL_FORUMS_EXPLAIN'						=> 'Auswählen wenn die Werbung in allen Foren angezeigt werden soll.',

	'CREATE_AD'									=> 'Erstelle Werbung',
	'CREATE_POSITION'							=> 'Erstelle Position',

	'DELETE_AD'									=> 'Lösche Werbung',
	'DELETE_AD_CONFIRM'							=> 'Bist du sicher, das du die Werbung löschen/verschieben möchtest?',
	'DELETE_AD_SUCCESS'							=> 'Die Werbung wurde erfolgreich gelöscht!',
	'DELETE_POSITION'							=> 'Lösche Position',
	'DELETE_POSITION_CONFIRM'					=> 'Bist du sicher, das du die Position löschen/verschieben möchtest?',
	'DELETE_POSITION_SUCCESS'					=> 'Die Position wurde erfolgreich gelöscht!',

	'FALSE'										=> 'Falsch / Inaktiv',

	'NO_ADS_CREATED'							=> 'Keine Werbung erstellt!',
	'NO_AD_NAME'								=> 'Du musst für die Werbung/Position einen Namen angeben.',
	'NO_POSITIONS_CREATED'						=> 'Keine Position erstellt.',

	'POSITION'									=> 'Position',
	'POSITION_CODE'								=> 'Position Code',
	'POSITION_EDIT_SUCCESS'						=> 'Position erfolgreich geändert!',
	'POSITION_NAME'								=> 'Position Name',
	'POSITION_NAME_EXPLAIN'						=> 'Name der Position.',
	'POSITION_NOT_EXIST'						=> 'Die ausgewählte Position ist nicht verfügbar.',
	'POSTITION_ADD_SUCCESS'						=> 'Standpunkt wurde erfolgreich gespeichert.Position Added Successfully!',
	'POSTITION_ALREADY_EXIST'					=> 'Sie haben bereits Werbung, mit diesem Namen.',

	'TRUE'										=> 'Wahr / Aktiv',
));

?>