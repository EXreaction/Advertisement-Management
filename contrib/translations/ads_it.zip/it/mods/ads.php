<?php
/**
*
* @package phpBB3 Advertisement Management
* @version $Id: ads.php 29 2008-03-20 00:06:08Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	// Default Positions
	'ABOVE_FOOTER'			=> 'Sopra Footer',
	'ABOVE_HEADER'			=> 'Sopra Testata',
	'ABOVE_POSTS'			=> 'Sopra i Posts',
	'AFTER_EVERY_POST'		=> 'Dopo ogni post, tranne il primo',
	'AFTER_FIRST_POST'		=> 'Dopo il primo post',
	'BELOW_FOOTER'			=> 'Sotto Footer',
	'BELOW_HEADER'			=> 'Sotto Testata',
	'BELOW_POSTS'			=> 'Sotto i Posts',

	// ACP
	'0_OR_NA'									=> '0 o N/A',

	'ACP_ADVERTISEMENT_MANAGEMENT_EXPLAIN'		=> 'Qui puoi cambiare le impostazioni di Gestione Sponsor, Aggiungere/Rimuovere/Modificare Posizione Pubblicita, e Aggiungere/Rimuovere/Modificare Pubblicita.',
	'ACP_ADVERTISEMENT_MANAGEMENT_SETTINGS'		=> 'Impostazioni Gestione Sponsor',
	'ADS_ACCURATE_VIEWS'						=> 'Conta Precisa Visite',
	'ADS_ACCURATE_VIEWS_EXPLAIN'				=> 'Conta le visite agli sponsor in modo accurato, ma aumenta il carico del server.',
	'ADS_COUNT_CLICKS'							=> 'Conta Click Ad',
	'ADS_COUNT_CLICKS_EXPLAIN'					=> 'Se messo a no, i click sugli sponsor non verranno contati (meno carico per il server).',
	'ADS_COUNT_VIEWS'							=> 'Conta Viste Ad',
	'ADS_COUNT_VIEWS_EXPLAIN'					=> 'Se messo a no, le visite agli sponsor non verranno contate (meno carico per il server).',
	'ADS_ENABLE'								=> 'Permetti Pubblicita',
	'ADS_RULES_FORUMS'							=> 'Utilizza le regole del Forum per gli sponsor',
	'ADS_RULES_FORUMS_EXPLAIN'					=> 'Se attivato, permette di controllare su quale forum ogni sponsor puo\' essere visualizzato. Se non hai intenzione di utilizzzare questa opzione, lascia disattivato il controllo per utilizzare meno risorse.',
	'ADS_RULES_GROUPS'							=> 'Utilizza Regole di Gruppo per gli sponsor',
	'ADS_RULES_GROUPS_EXPLAIN'					=> 'Se attivto, permette di controllare quali gruppi vedono/nonvedono specifici sponsor. Se non hai intenzione di utilizzare questa opzione, lascia disattivato il controllo per utilizzare meno risorse.',
	'ADS_VERSION'								=> 'Versione di Gestione Sponsor',
	'ADVERTISEMENT'								=> 'Sponsor',
	'ADVERTISEMENT_MANAGEMENT_UPDATE_SUCCESS'	=> 'Le impostazioni di Gestione Sponsor sono state aggiornate correttamente!',
	'AD_ADD_SUCCESS'							=> 'Sponsor Aggiunto correttamente!',
	'AD_CLICKS'									=> 'Ad Clicks',
	'AD_CLICKS_EXPLAIN'							=> 'Il numero effettivo di click per questo sponsor (se correttamente impostato).',
	'AD_CODE'									=> 'Codice Ad',
	'AD_CODE_EXPLAIN'							=> 'Il codice sponsor che vuoi venga mostrato. Tutti i codici dovrebbero essere inseriti in forma HTML grezza, il BBcode non e\' supportato.<br /><strong>Se desideri attivare il contatore di click, utilizza {COUNT_CLICK} dove preferisci dove l\'attributo onclick e\' permesso (per esempio il tag a).</strong>',
	'AD_EDIT_SUCCESS'							=> 'Sponsor Modificato Correttamente !',
	'AD_ENABLED'								=> 'Sponsor Attivato',
	'AD_ENABLED_EXPLAIN'						=> 'Togli il check per non mostrare lo sponsor.',
	'AD_FORUMS'									=> 'Lista Forum',
	'AD_FORUMS_EXPLAIN'							=> 'Seleziona i forum dove vuoi che venga mostrato questo sponsor. Puoi selezionare forum multipli premendo il tasto CTRL.',
	'AD_GROUPS'									=> 'Gruppi',
	'AD_GROUPS_EXPLAIN'							=> 'Seleziona i gruppi che <strong>NON</strong> vedranno questo sponsor. Puoi selezionare piu\' gruppi premendo il tasto CTRL.',
	'AD_LIST_NOTICE'							=> 'I Click per Sponsor saranno disponibili solo se hai utilizzato {COUNT_CLICK} in una zona dove possa funzionare l\' attributo onclick.',
	'AD_MAX_VIEWS'								=> 'Visite Massime',
	'AD_MAX_VIEWS_EXPLAIN'						=> 'Il numero massimo di visite prima che questo sponsor non venga piu\' mostrato. <strong>0 significa illimitato</strong>.',
	'AD_NAME'									=> 'Nome Sponsor',
	'AD_NAME_EXPLAIN'							=> 'Viene utilizzato solamente per riconoscere lo sponsor.',
	'AD_NOT_EXIST'								=> 'Lo sponsor selezionato non esiste.',
	'AD_POSITIONS'								=> 'Posizione',
	'AD_POSITIONS_EXPLAIN'						=> 'Seleziona la posizione dove vuoi venga mostrato lo sponsor.',
	'AD_PRIORITY'								=> 'Priorita\' Sponsor',
	'AD_PRIORITY_EXPLAIN'						=> 'Il numero piu\' alto rappresentala maggiore priorita\'. Per esempio, uno sponsor con una priorita\' a 2 verra\' doppiamente mostrato rispetto ad uno sponsor con priorita\' 1,priorita\' 3 lo mostrera\' triplicemente e via cosi.',
	'AD_VIEWS'									=> 'Visite Sponsor',
	'AD_VIEWS_EXPLAIN'							=> 'Il numero attuale di volte che e\' stato visto questo sponsor.',
	'ALL_FORUMS_EXPLAIN'						=> 'Seleziona per vederlo in tutti i forum.',

	'CREATE_AD'									=> 'Crea Sponsor',
	'CREATE_POSITION'							=> 'Crea Posizione',

	'DELETE_AD'									=> 'Elimina Sponsor',
	'DELETE_AD_CONFIRM'							=> 'Sei sicuro di voler rimuovere questo sponsor ?',
	'DELETE_AD_SUCCESS'							=> 'Lo sponsor e\' stato eliminato correttamente!',
	'DELETE_POSITION'							=> 'Elimina Posizione',
	'DELETE_POSITION_CONFIRM'					=> 'Sei sicuro di voler rimuovere questa posizione? Tutti gli sponsor che sono mostrati in essa non verranno piu\' mostrati.',
	'DELETE_POSITION_SUCCESS'					=> 'La posizione e\' stata eliminata correttamente!',

	'FALSE'										=> 'Falso',

	'NO_ADS_CREATED'							=> 'Nessun Sponsor creato',
	'NO_AD_NAME'								=> 'Devi dare un nome per questo sponsor.',
	'NO_POSITIONS_CREATED'						=> 'Nessuna Posizione Creata',

	'POSITION'									=> 'Posizione',
	'POSITION_CODE'								=> 'Codice Posizione',
	'POSITION_EDIT_SUCCESS'						=> 'Posizione Modificata Correttamente!',
	'POSITION_NAME'								=> 'Nome Posizione',
	'POSITION_NAME_EXPLAIN'						=> 'Il nome della posizione.',
	'POSITION_NOT_EXIST'						=> 'La posizione selezionata non esiste.',
	'POSTITION_ADD_SUCCESS'						=> 'Posizione Aggiunta Correttamente!',
	'POSTITION_ALREADY_EXIST'					=> 'Esiste gia\' una posizione cone questo nome.',

	'TRUE'										=> 'Vero',
));

?>
