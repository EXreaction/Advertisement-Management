<?php
/**
*
* @package phpBB3 Advertisement Management
* @version $Id: ads.php 29 2008-03-20 00:06:08Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
* translation by cedomirovic
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	// Default Positions
	'ABOVE_FOOTER'			=> 'Iznad Footer-a',
	'ABOVE_HEADER'			=> 'Iznad Header-a',
	'ABOVE_POSTS'			=> 'Iznad Postova',
	'AFTER_EVERY_POST'		=> 'Posle svakog posta izuzev prvog',
	'AFTER_FIRST_POST'		=> 'Posle prvog posta',
	'BELOW_FOOTER'			=> 'Ispod Footer-a',
	'BELOW_HEADER'			=> 'Ispod Header-a',
	'BELOW_POSTS'			=> 'Ispod Postova',

	// ACP
	'0_OR_NA'									=> '0 oili N/A',

	'ACP_ADVERTISEMENT_MANAGEMENT_EXPLAIN'		=> 'Ovde možeš da promeniš opcije Menadžment reklamiranja, Dodati/Obrisati/Promeniti pozicije Reklamiranja, i Dodati/Obrisati/Promeniti Reklame.',
	'ACP_ADVERTISEMENT_MANAGEMENT_SETTINGS'		=> 'Opcije Menadžment reklamiranja',
	'ADS_ACCURATE_VIEWS'						=> 'Tačan brojač pogleda',
	'ADS_ACCURATE_VIEWS_EXPLAIN'				=> 'Napravi brojač pogleda preciznije, ali povećavanjem učitavanja servera.',
	'ADS_COUNT_CLICKS'							=> 'Brojač pogleda',
	'ADS_COUNT_CLICKS_EXPLAIN'					=> 'Ako je postavljeno na ne, kliktanje na reklami neće biti računato (manje učitavanje servera).',
	'ADS_COUNT_VIEWS'							=> 'Brojač pogleda',
	'ADS_COUNT_VIEWS_EXPLAIN'					=> 'Ako je postavljeno na ne, kliktanje na reklami neće biti računato (manje učitavanje servera).',
	'ADS_ENABLE'								=> 'Omogući reklamiranje',
	'ADS_RULES_FORUMS'							=> 'Koristi forum pravila za reklame',
	'ADS_RULES_FORUMS_EXPLAIN'					=> 'Ako je omogućeno, možes da kontrolišeš koji forumi će posebno imati reklamu koja će se prikazivati.  Ako ne koristiš ovo postavi na ne da bi koristio manje resursa.',
	'ADS_RULES_GROUPS'							=> 'Koristi grupna pravila za reklame',
	'ADS_RULES_GROUPS_EXPLAIN'					=> 'Ako je omogućeno, možes da kontrolišeš koja grupa vidi/ne vidi specifične reklame.  Ako ne koristiš ovo postavi na ne da bi koristio manje resursa.',
	'ADS_VERSION'								=> 'Verzija Menadžment reklamiranja',
	'ADVERTISEMENT'								=> 'Reklamiranje',
	'ADVERTISEMENT_MANAGEMENT_UPDATE_SUCCESS'	=> 'Opcije Menadžment reklamiranja su uspešno ažurirane!',
	'AD_ADD_SUCCESS'							=> 'Reklame su uspešno dodate!',
	'AD_CLICKS'									=> 'Kliktanje',
	'AD_CLICKS_EXPLAIN'							=> 'Trenutni broj kliktanja za datu reklamu (ako je podešavanje korektno).',
	'AD_CODE'									=> 'Kod',
	'AD_CODE_EXPLAIN'							=> 'Kod ako želiš biće ovde prikazan.  Svi kodovi biće postavljeni u sirovoj HTML formi, BBcodes nisu podržani.<br /><strong>Ako želis da uključiš brojač kliktanja, koristi {COUNT_CLICK} na bilo kom mestu gde je jedan klik dozvoljen (tag kao primer).</strong>',
	'AD_EDIT_SUCCESS'							=> 'Reklame promenjene uspešno!',
	'AD_ENABLED'								=> 'Reklame omogućene',
	'AD_ENABLED_EXPLAIN'						=> 'Odčekiraj da onemogućiš ovu formu reklamiranja.',
	'AD_FORUMS'									=> 'Lista foruma',
	'AD_FORUMS_EXPLAIN'							=> 'Odaberi forume gde želiš da se reklame vide.  Možeš da izabereš više foruma držeći CTRL.',
	'AD_GROUPS'									=> 'Grupe',
	'AD_GROUPS_EXPLAIN'							=> 'Odaberi grupu <strong>NOT</strong> za koju hoćeš da reklama bude prikazana.  Možeš da odabereš više grupa držeći CTRL dok selektujes više grupa.',
	'AD_LIST_NOTICE'							=> 'Kliktanja će biti jedino moguća ako {COUNT_CLICK} su na mestu gde su dozvoljeni atributi kliktanja.',
	'AD_MAX_VIEWS'								=> 'Maksimalno pogleda',
	'AD_MAX_VIEWS_EXPLAIN'						=> 'Maksimalno gledanja pre this nogo što reklame više ne mogu da se prikazuju. <strong>0 means no max limit</strong>.',
	'AD_NAME'									=> 'Ime',
	'AD_NAME_EXPLAIN'							=> 'Ovo se samo koristi za tvoju organizaciju reklama.',
	'AD_NOT_EXIST'								=> 'Odabarana reklama ne postoji.',
	'AD_POSITIONS'								=> 'Pozicije',
	'AD_POSITIONS_EXPLAIN'						=> 'Odaberi poziciju gde želiš da se reklama pojavi.',
	'AD_PRIORITY'								=> 'Prioritet',
	'AD_PRIORITY_EXPLAIN'						=> 'Veći broj veći prioritet.  Na primer, reklama sa brojem 2 biće dva 2x prioritetnije od reklame sa brojem 1, 3 će biti 3x prioritetnije, itd, itd.',
	'AD_VIEWS'									=> 'Pogledi',
	'AD_VIEWS_EXPLAIN'							=> 'Trenutni broj gledanja reklame.',
	'ALL_FORUMS_EXPLAIN'						=> 'Odaberi da se prikazuje u svim formama.',

	'CREATE_AD'									=> 'Napravi reklamu',
	'CREATE_POSITION'							=> 'Kreiraj poziciju',

	'DELETE_AD'									=> 'Obriši reklamu',
	'DELETE_AD_CONFIRM'							=> 'Da li si siguran da želiš da obrišeš reklamu?',
	'DELETE_AD_SUCCESS'							=> 'Reklama je uspešno izbrisana!',
	'DELETE_POSITION'							=> 'Obriši poziciju',
	'DELETE_POSITION_CONFIRM'					=> 'Da li si siguran da želiš da obrišeš ovu poziciju?  Ako ukloniš poziciju, sve reklame koje su podešene za tu poziciju biće uklonjene.',
	'DELETE_POSITION_SUCCESS'					=> 'Pozicija je uspešno izbrisana!',

	'FALSE'										=> 'Netačno',

	'NO_ADS_CREATED'							=> 'Nema kreirane reklame',
	'NO_AD_NAME'								=> 'Moraš da napišeš ime reklame.',
	'NO_POSITIONS_CREATED'						=> 'Pozicija nije kreirana',

	'POSITION'									=> 'Pozicija',
	'POSITION_CODE'								=> 'Kod pozicije',
	'POSITION_EDIT_SUCCESS'						=> 'Pozicija uspešno izmenjena!',
	'POSITION_NAME'								=> 'Ime pozicije',
	'POSITION_NAME_EXPLAIN'						=> 'Objašnjenje imena pozicije.',
	'POSITION_NOT_EXIST'						=> 'Odabrana pozicija ne postoji.',
	'POSTITION_ADD_SUCCESS'						=> 'Pozicija uspešno dodana!',
	'POSTITION_ALREADY_EXIST'					=> 'Već postoji pozicija sa tim imenom.',

	'TRUE'										=> 'Tačno',
));

?>