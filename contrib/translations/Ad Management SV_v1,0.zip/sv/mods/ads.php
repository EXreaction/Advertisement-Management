<?php
/**
*
* @package phpBB3 Advertisement Management
* @version $Id: ads.php 29 2008-03-20 00:06:08Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
* Translated to Swedish by Christian Flack (info@flack.se), (www.flack.se) (c) 2008 
* Language Version: 1.0
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	// Default Positions
	'ABOVE_FOOTER'			=> 'Ovanför footer',
	'ABOVE_HEADER'			=> 'Ovanför header',
	'ABOVE_POSTS'			=> 'Ovanför inlägg',
	'AFTER_EVERY_POST'		=> 'Efter varje inlägg förutom det första',
	'AFTER_FIRST_POST'		=> 'Efter första inlägget',
	'BELOW_FOOTER'			=> 'Under footer',
	'BELOW_HEADER'			=> 'Under header',
	'BELOW_POSTS'			=> 'Under inlägg',

	// ACP
	'0_OR_NA'									=> '0 eller ej tillgänglig',

	'ACP_ADVERTISEMENT_MANAGEMENT_EXPLAIN'		=> 'Här kan du ändra annonssystemets inställningar, lägga till/ta bort/redigera annonspositioner och lägga till/ta bort/redigera annonser.',
	'ACP_ADVERTISEMENT_MANAGEMENT_SETTINGS'		=> 'Annonssystemets inställningar',
	'ADS_ACCURATE_VIEWS'						=> 'Exakt antal visningar',
	'ADS_ACCURATE_VIEWS_EXPLAIN'				=> 'Gör "antal visningar" mer exakt, men ökar belastningen på servern.',
	'ADS_COUNT_CLICKS'							=> 'Räkna annonsklick',
	'ADS_COUNT_CLICKS_EXPLAIN'					=> 'Om satt till nej, räknas inte antal annonsklick (mindre belastning på servern).',
	'ADS_COUNT_VIEWS'							=> 'Räkna annonsvisningar',
	'ADS_COUNT_VIEWS_EXPLAIN'					=> 'Om satt till nej, räknas inte antal annonsvisningar (mindre belastning på servern).',
	'ADS_ENABLE'								=> 'Aktivera annonser',
	'ADS_RULES_FORUMS'							=> 'Använd forumregler för annonser',
	'ADS_RULES_FORUMS_EXPLAIN'					=> 'Om aktiverad, låter dig välja vilka forum annonserna ska visas i.  Om du inte tänker använda detta ska detta vara satt till nej för att minska belastningen på servern.',
	'ADS_RULES_GROUPS'							=> 'Använd grupprättigheter för annonser',
	'ADS_RULES_GROUPS_EXPLAIN'					=> 'Om aktiverad, låter den dig kontrollera vilka grupper som ska se annonser.  Om du inte tänker använda detta ska detta vara satt till nej för att minska belastningen på servern.',
	'ADS_VERSION'								=> 'Annonssystemets version',
	'ADVERTISEMENT'								=> 'Annons',
	'ADVERTISEMENT_MANAGEMENT_UPDATE_SUCCESS'	=> 'Annonssystemets inställningar är sparade!',
	'AD_ADD_SUCCESS'							=> 'Annonsen sparad!',
	'AD_CLICKS'									=> 'Annonsklick',
	'AD_CLICKS_EXPLAIN'							=> 'Antal klick på denna annons (om inställningarna är korrekt satta).',
	'AD_CODE'									=> 'Lägg till annonskod',
	'AD_CODE_EXPLAIN'							=> 'Annonskoden placeras här. All kod ska skrivas i HTML-format, BBcodes får inte användas.<br /><strong>Om du vill använda klickräknaren, använd koden {COUNT_CLICK} i koden där "onclick attribut" är tillåtet (i "a"-taggen t.ex.).</strong>',
	'AD_EDIT_SUCCESS'							=> 'Annonsen redigerad!',
	'AD_ENABLED'								=> 'Annonsen är aktiv',
	'AD_ENABLED_EXPLAIN'						=> 'Klicka ur för att inte visa annonsen.',
	'AD_FORUMS'									=> 'Forumlista',
	'AD_FORUMS_EXPLAIN'							=> 'Välj forum där annonsen ska visas.  Välj flera forum genom att hålla ner CTRL-tangenten.',
	'AD_GROUPS'									=> 'Grupper',
	'AD_GROUPS_EXPLAIN'							=> 'Välj grupp där annonsen <strong>INTE</strong> ska visas.  Välj flera grupper genom att hålla ner CTRL-tangenten.',
	'AD_LIST_NOTICE'							=> 'Klickräknaren fungerar endast om du placerar {COUNT_CLICK} i koden där "onclick attribut" är tillåtet (i "a"-taggen t.ex.).',
	'AD_MAX_VIEWS'								=> 'Max antal visningar',
	'AD_MAX_VIEWS_EXPLAIN'						=> 'Antal visningar tills annonsen inte längre visas. <strong>0 betyder oändligt antal visningar</strong>.',
	'AD_NAME'									=> 'Annonsnamn',
	'AD_NAME_EXPLAIN'							=> 'Detta används bara för att du ska kunna identifiera dina annonser.',
	'AD_NOT_EXIST'								=> 'Den valda annonsen finns inte.',
	'AD_POSITIONS'								=> 'Positioner',
	'AD_POSITIONS_EXPLAIN'						=> 'Välj possition där du vill att annonsen ska visas.',
	'AD_PRIORITY'								=> 'Prioritet',
	'AD_PRIORITY_EXPLAIN'						=> 'Med ett högre nummer kommer annonsen att visas oftare.  t.ex. en annons med prioritet 2 har dubbelt så stor chans att visas än en annons med prioritet 1, 3 har 3 gånger så stor chans och så vidare.',
	'AD_VIEWS'									=> 'Visningar',
	'AD_VIEWS_EXPLAIN'							=> 'Antal gånger annonsen blivit visad.',
	'ALL_FORUMS_EXPLAIN'						=> 'Välj för att visa i alla forum.',

	'CREATE_AD'									=> 'Skapa annons',
	'CREATE_POSITION'							=> 'Skapa position',

	'DELETE_AD'									=> 'Ta bort annons',
	'DELETE_AD_CONFIRM'							=> 'Är du säker på att annonsen ska tas bort?',
	'DELETE_AD_SUCCESS'							=> 'Annonsen är borttagen!',
	'DELETE_POSITION'							=> 'Ta bort position',
	'DELETE_POSITION_CONFIRM'					=> 'Är du säker på att positionen ska tas bort?  Om du tar bort en position kommer de annonser med denna position inte att visas.',
	'DELETE_POSITION_SUCCESS'					=> 'positionen är borttagen!',

	'FALSE'										=> 'Falskt',

	'NO_ADS_CREATED'							=> 'Inga annonser skapade',
	'NO_AD_NAME'								=> 'Annonsen måste ha ett namn.',
	'NO_POSITIONS_CREATED'						=> 'Ingen position skapad',

	'POSITION'									=> 'Position',
	'POSITION_CODE'								=> 'Positionskod',
	'POSITION_EDIT_SUCCESS'						=> 'Position redigerad!',
	'POSITION_NAME'								=> 'Positionens namn',
	'POSITION_NAME_EXPLAIN'						=> 'Namnet på positionen.',
	'POSITION_NOT_EXIST'						=> 'Den valda positionen finns inte.',
	'POSTITION_ADD_SUCCESS'						=> 'Position skapad!',
	'POSTITION_ALREADY_EXIST'					=> 'Position med detta namn finns redan.',

	'TRUE'										=> 'Sant',
));

?>