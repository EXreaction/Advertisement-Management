<?php
/**
*
* @package phpBB3 Advertisement Management
* @version $Id: ads.php 29 2008-03-20 00:06:08Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	// Default Positions
	'ABOVE_FOOTER'			=> 'Boven Footer',
	'ABOVE_HEADER'			=> 'Boven Header',
	'ABOVE_POSTS'			=> 'Boven Berichten',
	'AFTER_EVERY_POST'		=> 'Na elk bericht behalve de eerste',
	'AFTER_FIRST_POST'		=> 'Na eerste bericht',
	'BELOW_FOOTER'			=> 'Onder Footer',
	'BELOW_HEADER'			=> 'Onder Header',
	'BELOW_POSTS'			=> 'Onder Berichten',

	// ACP
	'0_OR_NA'									=> '0 of N/A',

	'ACP_ADVERTISEMENT_MANAGEMENT_EXPLAIN'		=> 'Hier kan je de Advertentie Beheer Instellingen veranderen, Advertentie Posities Toevoegen/Verwijderen/Wijzigen, en Advertenties Toevoegen/Verwijderen/Wijzigen.',
	'ACP_ADVERTISEMENT_MANAGEMENT_SETTINGS'		=> 'Advertentie Beheer Instellingen',
	'ADS_ACCURATE_VIEWS'						=> 'Nauwkeurige View Tellingen',
	'ADS_ACCURATE_VIEWS_EXPLAIN'				=> 'Maakt tellingen van Advertentie Views meer accuraat, maar verhoogt de server belasting.',
	'ADS_COUNT_CLICKS'							=> 'Tel Advertentie Klikken',
	'ADS_COUNT_CLICKS_EXPLAIN'					=> 'Wanneer ingesteld op nee, zullen advertentie klikken niet worden geteld ( minder server belasting).',
	'ADS_COUNT_VIEWS'							=> 'Tel Advertentie Views',
	'ADS_COUNT_VIEWS_EXPLAIN'					=> 'Wanneer ingesteld op nee, zullen advertentie views niet worden geteld ( minder server belasting).',
	'ADS_ENABLE'								=> 'Advertenties Toestaan',
	'ADS_RULES_FORUMS'							=> 'Gebruik Forum Regels voor Advertenties',
	'ADS_RULES_FORUMS_EXPLAIN'					=> 'Indien toegelaten, staat het u toe om te controleren welke forums elke advertentie in wordt getoond.  Als je ervoor kiest om dit niet te gebruiken moet je dit op nee instellen zodat het minder resources gebruikt.',
	'ADS_RULES_GROUPS'							=> 'Gebruik Groep Regels voor Advertenties',
	'ADS_RULES_GROUPS_EXPLAIN'					=> 'Indien toegelaten, staat het u toe om te controleren welke groepen wel/niet specifieke advertenties zien.  Als je ervoor kiest om dit niet te gebruiken moet je dit op nee instellen zodat het minder resources gebruikt.',
	'ADS_VERSION'								=> 'Advertentie Beheer Versie',
	'ADVERTISEMENT'								=> 'Advertentie',
	'ADVERTISEMENT_MANAGEMENT_UPDATE_SUCCESS'	=> 'De Advertentie Beheer Instellingen zijn succesvol gewijzigd!',
	'AD_ADD_SUCCESS'							=> 'Advertenties succesvol toegevoegd!',
	'AD_CLICKS'									=> 'Advertentie Klikken',
	'AD_CLICKS_EXPLAIN'							=> 'Het huidige aantal klikken voor deze advertentie (mits correct ingesteld).',
	'AD_CODE'									=> 'Advertentie Code',
	'AD_CODE_EXPLAIN'							=> 'De Advertentie code die je wilt tonen komt hier, Alle code moet in HTML vorm worden ingevoerd, BBCodes worden niet ondersteund.<br /><strong>Als je de klik teller wilt toestaan, gebruik dan de {COUNT_CLICK} op elke plek waar het onclick atribuut is toegestaan. (bijvoorbeeld in de a tag).</strong>',
	'AD_EDIT_SUCCESS'							=> 'Advertentie succesvol gewijzigd!',
	'AD_ENABLED'								=> 'Advertentie Toegestaan',
	'AD_ENABLED_EXPLAIN'						=> 'Vink dit uit om deze advertentie niet meer te tonen.',
	'AD_FORUMS'									=> 'Forum Lijst',
	'AD_FORUMS_EXPLAIN'							=> 'Selecteer de Forums waar je deze advertentie wilt laten zien. Je kan meerdere Forums selecteren door de CTRL toets ingedrukt te houden.',
	'AD_GROUPS'									=> 'Groepen',
	'AD_GROUPS_EXPLAIN'							=> 'Selecteer de groepen die je deze advertentie <strong>NIET</strong>wilt laten tonen. Je kan meerdere groepen selecteren door de CTRL toets ingedrukt te houden.',
	'AD_LIST_NOTICE'							=> 'Advertentie Klikken zijn alleen beschikbaar als je gebruik maakt van de {COUNT_CLICK} tag op een plek die werkt met het onclick attribuut.',
	'AD_MAX_VIEWS'								=> 'Max Views',
	'AD_MAX_VIEWS_EXPLAIN'						=> 'De maximum views voordat deze advertentie niet meer wordt getoond. <strong>0 betekent oneindig</strong>.',
	'AD_NAME'									=> 'Advertentie Naam',
	'AD_NAME_EXPLAIN'							=> 'Dit is alleen voor herkenning van de advertentie.',
	'AD_NOT_EXIST'								=> 'De geselecteerde advertentie bestaat niet.',
	'AD_POSITIONS'								=> 'Posities',
	'AD_POSITIONS_EXPLAIN'						=> 'Selecteer de posities waar je deze advertentie wilt tonen.',
	'AD_PRIORITY'								=> 'Advertentie Prioriteit',
	'AD_PRIORITY_EXPLAIN'						=> 'Hoe hoger het nummer, hoe meer kans dat de advertentie wordt getoond. Bijvoorbeeld, een advertentie met een prioriteit van 2 zal waarschijnlijk 2x zoveel getoond dan een advertentie met een prioriteit van 1, 3 wordt waarschijnlijk 3x, etc, etc.',
	'AD_VIEWS'									=> 'Advertentie Views',
	'AD_VIEWS_EXPLAIN'							=> 'Het huidige aantal views van deze advertenties.',
	'ALL_FORUMS_EXPLAIN'						=> 'selecteer om in alle forums te tonen.',

	'CREATE_AD'									=> 'Creëer Advertentie',
	'CREATE_POSITION'							=> 'Creëer Positie',

	'DELETE_AD'									=> 'Verwijder Advertentie',
	'DELETE_AD_CONFIRM'							=> 'Weet je zeker dat je deze advertentie wilt verwijderen?',
	'DELETE_AD_SUCCESS'							=> 'De Advertentie is succesvol verwijderd!',
	'DELETE_POSITION'							=> 'Verwijder Positie',
	'DELETE_POSITION_CONFIRM'					=> 'Weet je zeker dat je deze positie wilt verwijderen? als je een positie verwijderd, zal elke advertentie die op die positie getoond worden, niet meer getoond worden.',
	'DELETE_POSITION_SUCCESS'					=> 'De positie is succesvol verwijderd!',

	'FALSE'										=> 'Niet waar',

	'NO_ADS_CREATED'							=> 'Geen advertenties gecreëerd',
	'NO_AD_NAME'								=> 'Je moet een naam opgeven voor de advertentie.',
	'NO_POSITIONS_CREATED'						=> 'Geen posities gecreëerd',

	'POSITION'									=> 'Positie',
	'POSITION_CODE'								=> 'Positie Code',
	'POSITION_EDIT_SUCCESS'						=> 'Positie succesvol gewijzigd!',
	'POSITION_NAME'								=> 'Positie Naam',
	'POSITION_NAME_EXPLAIN'						=> 'De naam van de positie.',
	'POSITION_NOT_EXIST'						=> 'De geselecteerde positie bestaat niet.',
	'POSTITION_ADD_SUCCESS'						=> 'Positie succesvol toegevoegd!',
	'POSTITION_ALREADY_EXIST'					=> 'Je hebt al een positie met die naam.',

	'TRUE'										=> 'Waar',
));

?>