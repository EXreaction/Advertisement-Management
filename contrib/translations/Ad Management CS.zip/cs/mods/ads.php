<?php
/**
*
* @package phpBB3 Advertisement Management
* @version $Id: ads.php 29 2008-03-20 00:06:08Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	// Default Positions
	'ABOVE_FOOTER'			=> 'Nad zápatím',
	'ABOVE_HEADER'			=> 'Nad záhlavím',
	'ABOVE_POSTS'			=> 'Nad příspěvky',
	'AFTER_EVERY_POST'		=> 'Po každém příspěvku kromě prvního',
	'AFTER_FIRST_POST'		=> 'Po prvním příspěvku',
	'BELOW_FOOTER'			=> 'Pod zápatím',
	'BELOW_HEADER'			=> 'Pod záhlavím',
	'BELOW_POSTS'			=> 'Pod příspěvky',

	// ACP
	'0_OR_NA'									=> '0 nebo N/A',

	'ACP_ADVERTISEMENT_MANAGEMENT_EXPLAIN'		=> 'Zde můžete měnit nastavení reklamních bannerů, přidat/odebrat/editovat umístění reklam a přidat/odebrat/editovat reklamy jako takové.',
	'ACP_ADVERTISEMENT_MANAGEMENT_SETTINGS'		=> 'Nastavení reklamních bannerů',
	'ADS_ACCURATE_VIEWS'						=> 'Přesný počet zobrazení',
	'ADS_ACCURATE_VIEWS_EXPLAIN'				=> 'Umožňuje mnohem přesnějsí počítání zobrazení reklam, vyžaduje ale větší zátěž na server.',
	'ADS_COUNT_CLICKS'							=> 'Počet kliknutí na banner',
	'ADS_COUNT_CLICKS_EXPLAIN'					=> 'Pokud je nastaveno na NE, informace o počtu kliknutí na banner se nebude uchovávat (představuje nižší zatížení serveru).',
	'ADS_COUNT_VIEWS'							=> 'Počet zobrazení banneru',
	'ADS_COUNT_VIEWS_EXPLAIN'					=> 'Pokud je nastaveno na NE, informace o počtu zobrazení banneru se nebude uchovávat (představuje nižší zatížení serveru).',
	'ADS_ENABLE'								=> 'Umožnit použití reklamních bannerů',
	'ADS_RULES_FORUMS'							=> 'Použití pravidel fóra pro reklamní bannery',
	'ADS_RULES_FORUMS_EXPLAIN'					=> 'Pokud je povoleno, je možné kontrolovat, ve kterém fóru se zobrazuje ten který reklamní banner. Pokud neplánujete tuto funkci využívat, zvolte NE. Snížíte tím zátěž na server.',
	'ADS_RULES_GROUPS'							=> 'Použití pravidel skupin pro reklamní bannery',
	'ADS_RULES_GROUPS_EXPLAIN'					=> 'Pokud je povoleno, je možné kontrolovat, které uživatelské skupiny vidí/nevidí konkrétní reklamní bannery. Pokud neplánujete tuto funkci využívat, zvolte NE. Snížíte tím zátěž na server.',
	'ADS_VERSION'								=> 'Verze aplikace pro nastavení reklamních bannerů',
	'ADVERTISEMENT'								=> 'Reklamní banner',
	'ADVERTISEMENT_MANAGEMENT_UPDATE_SUCCESS'	=> 'Nastavení reklamních bannerů bylo úspěšně změněno!',
	'AD_ADD_SUCCESS'							=> 'Reklamní banner úspěšně přidán!',
	'AD_CLICKS'									=> 'Kliknutí',
	'AD_CLICKS_EXPLAIN'							=> 'Aktuální počet kliknutí pro tento reklamní banner (pokud je vše správně nastaveno).',
	'AD_CODE'									=> 'Kód reklamního banneru',
	'AD_CODE_EXPLAIN'							=> 'Zde vložte kód reklamního banneru, který chcete zobrazit. Kód musí být pouze v HTML formátu, BBCode není podporován.<br /><strong>Pokud budete chtít povolit počítání kliknutí, použijte řetězec {COUNT_CLICK} kdekoliv, kde je povolen atribut onclick (např. tag).</strong>',
	'AD_EDIT_SUCCESS'							=> 'Reklamní banner úspěšně editován!',
	'AD_ENABLED'								=> 'Povoleno',
	'AD_ENABLED_EXPLAIN'						=> 'Odklikněte pro nezobrazování tohoto banneru.',
	'AD_FORUMS'									=> 'Seznam diskuzního fóra',
	'AD_FORUMS_EXPLAIN'							=> 'Vyberte ta fóra, kde chcete, aby se tento reklamní banner zobrazoval. Je možné vybrat víc fór podržením klávesy CTRL.',
	'AD_GROUPS'									=> 'Uživatelské skupiny',
	'AD_GROUPS_EXPLAIN'							=> 'Vyberte ty skupiny, kterým se tento reklamní banner <strong>NEMÁ</strong> zobrazovat. Je možné vybrat víc skupin podržením klávesy CTRL.',
	'AD_LIST_NOTICE'							=> 'Zobrazení počtu kliknutí bude dostupné pouze v případě, že používáte správně umístěný řetězec {COUNT_CLICK}.',
	'AD_MAX_VIEWS'								=> 'Maximální počet zobrazení',
	'AD_MAX_VIEWS_EXPLAIN'						=> 'Počet zobrazení, při kterém se reklamní banner přestane zobrazovat. <strong>0 znamená bez omezení</strong>.',
	'AD_NAME'									=> 'Jméno',
	'AD_NAME_EXPLAIN'							=> 'Slouží pro rozpoznání příslušného banneru.',
	'AD_NOT_EXIST'								=> 'Vybraný reklamní banner neexistuje.',
	'AD_POSITIONS'								=> 'Umístění',
	'AD_POSITIONS_EXPLAIN'						=> 'Vyberte umístění, kde se má banner zobrazovat.',
	'AD_PRIORITY'								=> 'Priorita',
	'AD_PRIORITY_EXPLAIN'						=> 'Čím vyšší číslo, tím častěji se bude reklamní banner zobrazovat. Např. banner s prioritou 2 se bude zobrazovat 2x častěji než banner s prioritou 1.',
	'AD_VIEWS'									=> 'Zobrazení',
	'AD_VIEWS_EXPLAIN'							=> 'Aktuální počet zobrazení tohoto reklamního banneru.',
	'ALL_FORUMS_EXPLAIN'						=> 'Vybrat pro zobrazení ve všech fórech.',

	'CREATE_AD'									=> 'Vytvořit raklamní banner',
	'CREATE_POSITION'							=> 'Vytvořit umístění',

	'DELETE_AD'									=> 'Smazat reklamní banner',
	'DELETE_AD_CONFIRM'							=> 'Opravdu chcete tento reklamní banner odstranit?',
	'DELETE_AD_SUCCESS'							=> 'Reklamní banner byl úspěšně smazán!',
	'DELETE_POSITION'							=> 'Smazat pozici',
	'DELETE_POSITION_CONFIRM'					=> 'Opravdu chcete toto umístění smazat? Pokud umístění odstraníte, reklamní bannery, které se na tomto umístění zobrazovaly, se již zobrazovat nebudou.',
	'DELETE_POSITION_SUCCESS'					=> 'Umístění bylo úspěšně smazáno!',

	'FALSE'										=> 'Ne',

	'NO_ADS_CREATED'							=> 'Nevytvořen žádný reklamní banner',
	'NO_AD_NAME'								=> 'Musíte zvolit jméno reklamního banneru.',
	'NO_POSITIONS_CREATED'						=> 'Nevytvořena žádná umístění',

	'POSITION'									=> 'Umístění',
	'POSITION_CODE'								=> 'Kód umístění',
	'POSITION_EDIT_SUCCESS'						=> 'Umístění úspěšně editováno!',
	'POSITION_NAME'								=> 'Jméno umístění',
	'POSITION_NAME_EXPLAIN'						=> 'Pojmenování příslušného umístění.',
	'POSITION_NOT_EXIST'						=> 'Vybrané umístění neexistuje.',
	'POSTITION_ADD_SUCCESS'						=> 'Umístění úspěšně přidáno!',
	'POSTITION_ALREADY_EXIST'					=> 'Už máte takto pojmenované jiné umístění.',

	'TRUE'										=> 'Ano',
));

?>